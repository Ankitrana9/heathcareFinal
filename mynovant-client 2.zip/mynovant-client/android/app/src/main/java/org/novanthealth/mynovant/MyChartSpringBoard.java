package org.novanthealth.mynovant;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.facebook.react.common.ReactConstants;

import epic.mychart.android.library.api.general.WPAccessResult;
import epic.mychart.android.library.api.springboard.WPAPIHomepage;
import epic.mychart.android.library.api.springboard.WPAPISpringboard;

public class MyChartSpringBoard {

    private Context applicationContext;

    public MyChartSpringBoard() {}

    public MyChartSpringBoard(Context context) {
        this.applicationContext = context;
    }

    public void launchMyChart() {
        Log.d(ReactConstants.TAG, "MyChartECheckIn#launchMyChart");



        WPAccessResult result = WPAPIHomepage.accessResultForHomepage();

        Log.d(ReactConstants.TAG, "MyChartECheckIn#Result is ==> " + result);

        Log.d(ReactConstants.TAG, "What is this context? ==> " + applicationContext.getPackageName());

        if (result == WPAccessResult.ACCESS_ALLOWED) {

            Intent springboard = WPAPIHomepage.makeHomepageIntent(applicationContext);

            springboard.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            MyChartModule.startMyChartTimer();
            applicationContext.startActivity(springboard);
            MainActivity.setMyChartOpen(true);

        } else if (result == WPAccessResult.MISSING_SECURITY) {
            Log.d(ReactConstants.TAG, "Could not use new Homepage, falling back to Springboard...");
            result = WPAPISpringboard.accessResultForSpringboard();
            if (result == WPAccessResult.ACCESS_ALLOWED) {
                Intent springboard = WPAPISpringboard.makeSpringboardIntent(applicationContext);

                springboard.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                MyChartModule.startMyChartTimer();

                applicationContext.startActivity(springboard);
            } else {
                cannotCallSpringBoard(result);
            }
        } else {
            cannotCallSpringBoard(result);
        }
    }

    public void cannotCallSpringBoard(WPAccessResult result) {
        Log.d(ReactConstants.TAG, "==> Could not launch Springboard: " + result.name());
    }
}
