import React from "react";
import {Container, Content, H1, H2, Text, View} from "native-base";
import {Linking, StyleSheet} from "react-native";
import {palette} from "../../Style";

export class MyChartTAndCs extends React.Component {
    render() {
        return (
            <Container testID='MyChartTAndCs' style={{padding: 10}}>
                <Content>
                    <View>
                            <H2 style={Styles.subText}>
                            MyChart
                            </H2>
                            <Text style={Styles.text}>
                                MyChart is an easy way to access some, but not all, of your medical record online. With
                                MyChart, you can see parts of your medical record, ask for prescription renewals, schedule
                                appointments, and send online messages to your doctor and staff.
                            </Text>
                            <Text style={Styles.text}>
                                Protecting the confidentiality of your medical information is important to us. We use
                                industry standard security measures to protect your logon credentials (username and
                                password) and your medical information. We log your use of MyChart including the medical
                                records you access and release. For security and compatibility, MyChart must be accessed
                                with browser that supports modern web site encryption (e.g. HTTPS / Transport Layer Security
                                1.3 (TLS)).
                            </Text>
                           <Text style={Styles.text}>
                               MyChart is offered only as a convenience. You do not have to use it if you do not want to.
                               If you decide to use MyChart, whether as a patient or as a proxy for your child or another
                               person, you agree to all the terms and conditions listed below. Read them very carefully
                               before using MyChart. We can change these terms and conditions at any time, without notice
                               to you.
                           </Text>
                            <H2 style={Styles.subText}>
                            MyChart Terms and Conditions
                            </H2>
                            <Text style={Styles.text}>
                            In exchange for being able to use MyChart, I understand and agree that:
                            </Text>
                            <Text style={Styles.text}>
                                <Text style={Styles.boldText}>• I will not use MyChart for emergencies.</Text>
                                 If I have an emergency or anything else that must
                                be handled quickly, I will call 911 or go to the emergency room.
                            </Text>
                            <Text style={Styles.text}>
                                • Novant Health tries hard to answer messages in a timely manner. I will allow at least two
                                (2) business days for a response.
                            </Text>
                            <Text style={Styles.text}>
                                • I will change my password regularly.
                            </Text>
                            <Text style={Styles.text}>
                                • I will not give my user ID or password to anyone else to enable another person to use my
                                MyChart account. If I think someone else has my password, I will change it immediately.
                            </Text>
                            <Text style={Styles.text}>
                                • MyChart offers options for me to use applications of third parties unrelated to Novant
                                Health to retrieve information about me from MyChart while I am logged into MyChart. Novant
                                Health is not, and will not agree to be, a party to any agreements or understandings I may
                                have with third parties concerning any these applications.
                            </Text>
                            <Text style={Styles.text}>
                                • Novant Health does not endorse
                                these applications, does not make any representations about the confidentiality, security,
                                or integrity of information retrieved by these applications, and I assume all risk
                                associated with using these applications.
                            </Text>
                            <Text style={Styles.text}>
                                • If I decide to share my MyChart user ID and
                                password directly with another application or website and later decide to revoke access, I
                                must change my MyChart password.
                            </Text>
                            <Text style={Styles.text}>
                                • I will carefully choose the email address I want to use for MyChart. Anyone with access to
                                this email account will be able to see the notifications.
                                • I consent to Novant Health, or its vendor, sending e-mail communications to the e-mail
                                address provided for MyChart for both notifications concerning MyChart services and for
                                other medical, business and promotional purposes.
                            </Text>
                            <Text style={Styles.text}>
                                • I understand that Novant Health cannot
                                ensure the security of e-mail. I understand e-mail should not be used for emergencies or
                                other issues that must be handled quickly, or for communication of sensitive information.
                            </Text>
                            <Text style={Styles.text}>
                                • I also understand that I may opt out of receiving additional e-mail communications for other
                                medical, business or promotional purposes by following directions for opting out of
                                receiving e-mails.
                            </Text>
                            <Text style={Styles.text}>
                                • In order to facilitate the security of my personal medical records, I will only access
                                MyChart using website links provided by Novant Health (such as {'\xa0'}
                                <Text style={{...Styles.text, ...otherStyles.link}}
                                      onPress={() =>
                                          Linking.openURL('https://www.novantmychart.org')}
                                >
                                    https://www.novantmychart.org
                                </Text> {'\xa0'}
                                 or {'\xa0'}
                                <Text style={{...Styles.text, ...otherStyles.link}}
                                      onPress={() =>
                                          Linking.openURL('https://www.novanthealth.org/mynovant.aspx?utm_source=mynovant.org&utm_medium=Referral')}
                                >
                                    www.mynovant.org
                                </Text>) while using a modern, up-to-date web browser. I will not access MyChart
                                if the browser indicates that the site may not be secure.
                            </Text>
                            <Text style={Styles.text}>
                                • Novant Health will never ask me for my password in any communication, including email. If
                                I am asked for my user ID or password, I will report it immediately to the toll-free
                                Customer Service Line at {'\xa0'}
                                <Text style={{...Styles.text, ...otherStyles.link}}
                                      onPress={() =>
                                          Linking.openURL('tel://855-803-3742')}
                                >
                                    855-803-3742
                                </Text>, and enter “1” for MyChart assistance, Monday through
                                Friday, 8 a.m. to 6 p.m. (EST).
                            </Text>
                            <Text style={Styles.text}>
                                <Text style={Styles.boldText}>• I will not use MyChart to send messages about medical issues I think are sensitive. </Text>
                                Team members who are not doctors or nurses will help answer messages. If I am not comfortable
                                with other people seeing my message, I will not send it. I will make an appointment so I can
                                talk directly with my doctor instead.
                            </Text>
                            <Text style={Styles.text}>
                                <Text style={Styles.boldText}>• MyChart is not my complete medical record, nor is it my official Novant Health medical
                                    record. </Text>
                                 I will not be able to view the entire medical record through MyChart – I will only
                                have access to some parts of it. If I need a copy of the medical record, I may request the
                                medical record through MyChart or by contacting the Novant Health Enterprise Release of
                                Information Department at {'\xa0'}
                                <Text style={{...Styles.text, ...otherStyles.link}}
                                      onPress={() =>
                                          Linking.openURL('tel://1-844-763-9163')}
                                >
                                    1-844-763-9163
                                </Text> or by visiting {'\xa0'}
                                <Text style={{...Styles.text, ...otherStyles.link}}
                                      onPress={() =>
                                          Linking.openURL('https://www.novanthealth.org/home/patients--visitors/medical-records.aspx?utm_source=all&utm_medium=medicalrecords&utm_campaign=Vanity%20URL')}
                                >
                                    novanthealth.org/medicalrecords.
                                </Text>
                            </Text>
                            <Text style={Styles.text}>
                                • MyChart provides opportunities to notify my doctor of updates to my conditions. For
                                example, I can use MyChart to update my doctor about my allergies, my medications, and my
                                current health problems, or to send messages to my doctor.
                            </Text>
                            <Text style={Styles.text}>
                                <Text style={Styles.boldText}>• If I believe that medical
                                    information in my medical record is inaccurate, </Text>
                                 I will request an amendment of my medical
                                record by completing the Request to Exercise Privacy Rights – Amendment of Medical Record
                                form found at {'\xa0'}
                                <Text style={{...Styles.text, ...otherStyles.link}}
                                      onPress={() =>
                                          Linking.openURL('https://www.novanthealth.org/Portals/92/novant_health/documents/patients_visitors/medical%20records/ExercisePrivacyRtsAmendMR-NH_803190.pdf')}
                                >
                                    https://www.novanthealth.org/Portals/92/novant_health/documents/patients_visitors/medical%20records/ExercisePrivacyRtsAmendMR-NH_803190.pdf
                                </Text>
                                {'\xa0'} and will return it to Novant Health Enterprise Release of Information by fax at 704-316-9556
                                or by email to {'\xa0'}
                                <Text style={{...Styles.text, ...otherStyles.link}}
                                      onPress={() =>
                                          Linking.openURL('mailto:RPG635@novanthealth.org')}
                                >
                                    RPG635@novanthealth.org
                                </Text>. If I believe any payment or demographic information
                                is incorrect, I will contact Novant Health Revenue Cycle Services at{'\xa0'}
                                <Text style={{...Styles.text, ...otherStyles.link}}
                                      onPress={() =>
                                          Linking.openURL('tel://844-648-7999')}
                                >
                                    844-648-7999.
                                </Text>
                            </Text>
                            <Text style={Styles.text}>
                                • Most, but not all test results will be available through MyChart once the results are
                                final. I know that I will likely see results before my healthcare provider has had a chance
                                to review them.
                            </Text>
                            <Text style={Styles.text}>
                                    • I understand that I can view my test results in MyChart right away or wait
                                    until my provider’s office contacts me directly to help me understand what my result(s)
                                    mean. If I do not have a scheduled appointment or have not heard from my provider within a
                                    few days I can contact my provider’s office to schedule a follow up appointment.
                            </Text>
                            <Text style={Styles.text}>
                                <Text style={Styles.boldText}>
                                    • MyChart is offered as a tool for managing my healthcare.
                                    Novant Health can terminate my
                                    access for inappropriate use, without notice.</Text>
                            </Text>
                            <Text style={Styles.text}>
                                    • If I do not want to use MyChart, I will ask my doctor’s office to deactivate my account.
                                    If I do not want my proxy to use MyChart to see my medical information anymore, I will ask
                                    my doctor’s office to deactivate the account. I understand that it may take several days to
                                    process my request. During this time, my proxy will still be able to access my medical
                                    information.
                            </Text>
                            <Text style={Styles.text}>
                                • If I have access to the MyChart account of my child or another person, I understand that
                                my access can be revoked at any time by Novant Health. My access will also be revoked when
                                my child turns 18, my child is emancipated, parent/child access disputes cannot be resolved,
                                or if my child asks for it to be revoked.
                            </Text>
                            <Text style={Styles.text}>
                                • MyChart may offer links to related medical websites that are not managed by Novant Health.
                                These website link(s) are for informational purposes only. I will not rely on any of the
                                information I find on these websites for any reason. If I am concerned or have questions
                                about my health or any symptoms I have, or that of my child or another person, I will make
                                an appointment with my doctor.
                            </Text>
                            <Text style={Styles.text}>
                                • Novant Health does not endorse, and has not verified, the
                                accuracy of any of the information on these websites. I use them at my own risk. It is my
                                responsibility to follow the terms and conditions of use and the privacy statements of other
                                websites.
                            </Text>
                            <Text style={Styles.text}>
                                • Novant Health does not endorse, and has not verified, the
                                accuracy of any of the information on these websites. I use them at my own risk. It is my
                                responsibility to follow the terms and conditions of use and the privacy statements of other
                                websites.
                            </Text>
                            <Text style={Styles.text}>
                                • Information may be transmitted over a medium that is beyond the control of Novant Health
                                and its contractors. I EXPRESSLY ASSUME THE SOLE RISK OF ANY UNAUTHORIZED DISCLOSURE OR
                                INTENTIONAL INTRUSION, OR OF ANY DELAY, FAILURE, INTERRUPTION OR CORRUPTION OF DATA OR OTHER
                                INFORMATION TRANSMITTED IN CONNECTION WITH THE USE OF THIS SERVICE.

                            </Text>
                            <Text style={Styles.text}>
                                • The website and all other sites hosted by Novant Health and their content are provided by
                                Novant Health on an "as is" basis. Novant Health makes no representations or warranties of
                                any kind, express or implied, about the operation of its sites, or the content, products
                                and/or services included therein. To the fullest extent permissible by applicable law,
                                Novant Health disclaims all warranties, express or implied, including but not limited to
                                implied warranties of merchantability, fitness for a particular purpose, title, and/or
                                infringement.
                            </Text>
                            <Text style={Styles.text}>
                                • I acknowledge that Novant Health has the right to modify these terms and conditions at any
                                time, in its sole discretion, and the modifications will become effective as of the date of
                                they are posted. I agree to re-review these terms and conditions and the Novant Health
                                Notice of Privacy Practices each time I receive notice of (or otherwise become aware of)
                                these modifications. My continued use of MyChart constitutes my acceptance of all of the
                                modifications that Novant Health has made.
                            </Text>
                            <Text style={Styles.text}>
                                If I do not agree with the modifications to these
                                terms and conditions or any of our changes to the Notice of Privacy Practices, I will
                                discontinue my access to and use of MyChart. Neither the course of conduct between the
                                parties nor trade practice will act to modify any provision of these terms and conditions.
                                I have read the MyChart Terms and Conditions. I understand them. I agree to them. I consent
                                to the Terms and Conditions voluntarily.
                            </Text>
                    </View>
                </Content>
            </Container>
        )
    }
}


const newLine = 22

const Styles = StyleSheet.create({
    date: {
        color: 'black',
        fontFamily: 'Whitney-Medium',
        fontSize: 16
    },
    headerText: {
        marginTop: newLine,
        color: palette.onyx,
        fontWeight: 'bold',
        fontFamily: 'Whitney-Medium',
        fontSize: 26,
        marginBottom: newLine,
    },
    subText: {
        marginTop: newLine,
        color: palette.onyx,
        fontWeight: 'bold',
        fontFamily: 'Whitney-Medium',
        fontSize: 20,
        marginBottom: newLine,
    },
    redColorText: {
        color: 'red',
        fontFamily: 'Whitney-Medium',
        fontSize: 18
    },
    boldText: {
        color: palette.onyx,
        fontFamily: 'Whitney-Medium',
        fontWeight: 'bold',
        fontSize: 18
    },
    text: {
        color: 'black',
        fontFamily: 'Whitney-Medium',
        fontSize: 18,
        lineHeight:24,
        marginBottom: newLine,
    }
})

const otherStyles = StyleSheet.create({
    indented: {
        ...Styles.text,
        marginLeft: 22,
    },
    link: {
        color: 'blue'
    }
})

