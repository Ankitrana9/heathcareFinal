import {fireEvent, render} from "react-native-testing-library";
import '@testing-library/jest-native/extend-expect';
import {fireEventChangeText, fireEventCustom} from "../../support/specHelper";
import React from "react";
import {FieldTemplate} from "./FieldTemplate";
import {palette} from "../../Style";

describe('FieldTemplate', () => {
    let container
    let props: any

    beforeEach(() => {
        props = {
            label: 'aLabel',
            testID: 'testID',
            value: '',
            onChange: jest.fn(),
            error: false
        }

        container = render(<FieldTemplate {...props} />)
    })

    describe('Field Template options',() => {

        it('should not have an eye icon by default', async () => {
            expect(container.queryByTestId('secureEye')).toBeFalsy()
        })

        it('should have a label', async () => {
            expect(container.queryByText('aLabel')).toBeTruthy()
        })

        it('should have an eye-with-line icon', async () => {
            await fireEventCustom(container.getByTestId('testID'), 'onFocus')
            expect(container.queryByTestId('secureEye')).toBeTruthy()
        })

        it('should remove the eye icon when blurred and no password text', async () => {
            await fireEvent(container.getByTestId('testID'), 'onBlur')

            expect(container.queryByTestId('secureEye')).toBeFalsy()
        })

        it('should retain the eye icon when blurred and has password text', async () => {
            await fireEventChangeText(container.getByTestId('testID'), 'a text')

            expect(props.onChange).toHaveBeenCalledWith('a text')
        })

        it('should have another testID and another label', async () => {
            props.label = 'anotherLabel'
            props.testID = 'anotherTestID'
            container = render(<FieldTemplate {...props} />)

            expect(container.queryByText('anotherLabel')).toBeTruthy()
            expect(container.queryByTestId('anotherTestID')).toBeTruthy()

            await fireEventChangeText(container.getByTestId('anotherTestID'), 'another text')

            expect(props.onChange).toHaveBeenCalledWith('another text')
        })

        it('should the label and bottom line turn Red when error is occurred', async () => {
            props.error = true
            container = render(<FieldTemplate {...props} />)

            expect(container.getAllByTestId('fieldTemplateView')[0]).toHaveStyle({borderBottomColor: palette.red})
            expect(container.getAllByTestId('fieldLabel')[0]).toHaveStyle({color: palette.red})
        })

    })

})
