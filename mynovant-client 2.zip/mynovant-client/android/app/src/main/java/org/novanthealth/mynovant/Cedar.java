package org.novanthealth.mynovant;

import android.content.Context;
import android.util.Log;

import com.facebook.react.bridge.Callback;

import epic.mychart.android.library.api.extensibility.WPAPIFDILink;
import epic.mychart.android.library.api.general.WPError;
import epic.mychart.android.library.api.patient.IWPPatient;
import epic.mychart.android.library.api.patient.WPAPIPatientManager;
import epic.mychart.android.library.api.shared.IWPPerson;
import epic.mychart.android.library.api.shared.WPAPIPersonManager;

class Cedar implements WPAPIFDILink.IWPOnGetFDILink {

    Callback callback;

    public Cedar(Callback callback) {
        this.callback = callback;
        IWPPatient patient = WPAPIPatientManager.getCurrentPatient();
        Context context = MyChartModule.getReactContext().getApplicationContext();
        WPAPIFDILink.getUrlString(context, patient, "100085", this);
    }

    @Override
    public void onSucceeded(String s) {
        Log.d("ReactNative", "Cedar#getCedarUrl -> " + s);
        this.callback.invoke(s);
    }

    @Override
    public void onFailed(WPError wpError) {
        Log.d("ReactNative", "Cedar#getCedarUrl -> " + wpError.getMessage());
    }
}
