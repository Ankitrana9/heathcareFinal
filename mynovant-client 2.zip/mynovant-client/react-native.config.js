module.exports = {
    project: {
        ios: {},
        android: {}
    },
    assets: [
        './assets/',
        './assets/fonts/',
        // './node_modules/native-base/Fonts/'
    ]
}
