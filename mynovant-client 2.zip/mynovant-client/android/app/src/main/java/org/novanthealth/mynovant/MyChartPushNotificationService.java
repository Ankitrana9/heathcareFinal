package org.novanthealth.mynovant;

import android.util.Log;

import com.facebook.react.common.ReactConstants;
import com.google.firebase.messaging.RemoteMessage;

import epic.mychart.android.library.api.pushnotifications.WPAPIFirebaseMessagingService;

public class MyChartPushNotificationService extends WPAPIFirebaseMessagingService {

    @Override
    public void onNewToken(String token) {
        // do nothing. We don't want push notifications
        // from MyChart at this time...
        // super.onNewToken(token);
        Log.d(ReactConstants.TAG,
                "MyChartPushNotificationService#onNewToken " + token);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // do nothing. We don't want push notifications
        // from MyChart at this time...
        // super.onMessageReceived(remoteMessage)
        Log.d(ReactConstants.TAG,
                "MyChartPushNotificationService#onNewToken " + remoteMessage.getFrom());
    }
}
