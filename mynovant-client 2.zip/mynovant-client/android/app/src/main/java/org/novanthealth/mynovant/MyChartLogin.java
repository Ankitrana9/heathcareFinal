package org.novanthealth.mynovant;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.facebook.react.common.ReactConstants;

import epic.mychart.android.library.api.accountsettings.WPAPIAccountSettings;
import epic.mychart.android.library.api.authentication.WPAPIAuthentication;

import com.google.android.gms.measurement.module.Analytics;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.encoders.annotations.Encodable;

public class MyChartLogin extends AppCompatActivity
        implements WPAPIAuthentication.IWPOnLoginListener, WPAPIAccountSettings.WPAPIPushNotificationsListener {

    private static int LOGIN_REQUEST_CODE = 9876;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(ReactConstants.TAG, "MyChartLogin#onCreate");

        setContentView(R.layout.login_loading_screen);

        this.login(
            this.getIntent().getStringExtra("username"),
            this.getIntent().getStringExtra("password")
        );
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        Log.d(ReactConstants.TAG, "MyChartLogin#onActivityResult");
        try {
            if (requestCode == LOGIN_REQUEST_CODE) {
                if (resultCode == Activity.RESULT_OK) {
                    Log.d("ReactNative", "Authentication successful!" + resultCode);

                    if (this.getIntent().getBooleanExtra("isProd", false)) {
                        Log.d(ReactConstants.TAG, "MyChartLogin#onActivityResult - logging event to GA");

                        Bundle bundle = new Bundle();
                        bundle.putString("app", "MyNovant");

                        FirebaseAnalytics.getInstance(this)
                                .logEvent(FirebaseAnalytics.Event.LOGIN, bundle);
                    }

                    // check if push notifications enabled,
                    WPAPIAccountSettings.getPushNotificationsStatus(this);

                    MyChartModule.emitEventMyChartAuthResponse(true);
                } else {
                    // all other problems
                    Log.d("ReactNative", "Authentication failed. Something else happened..." + resultCode);
                    MyChartModule.emitEventMyChartAuthResponse(false);

                    WPAPIAuthentication.WPLoginResult result = WPAPIAuthentication.getLoginResult(intent);

                    Log.d("ReactNative", "Error Name..." + result.name());
                    Log.d("ReactNative", "Error Message..." + result.getErrorMessage(this.getContext()));

                    Log.d("ReactNative", "MyChartLogin#onActivityResult -> Login Error");

                    try {
                        Thread.sleep(250);
                    } catch (InterruptedException e) {
                        Log.d(ReactConstants.TAG, "MyChartLogin#onActivityResult");
                        Log.d(ReactConstants.TAG, "Error when sleeping" + e.getStackTrace());
                    }
                }
            }
        } catch (Exception e) {
            MyChartModule.emitEventMyChartAuthResponse(false);
        } finally {
            Log.d("ReactNative", "MyChartLogin#onActivityResult -> Close the activity");
            this.finish();
        }
    }

    @Override
    public Context getContext() {
        Log.d(ReactConstants.TAG, "MyChartLogin#getContext");
        return this;
    }

    public void login(String username, String password) {
        Log.d(ReactConstants.TAG, "MyChartLogin#login");

        try {
            WPAPIAuthentication.login(this, username, password, LOGIN_REQUEST_CODE);
        } catch (Exception e) {
            MyChartModule.emitEventMyChartAuthResponse(false);
        }
    }

    /**
     * Methods for WPAPIAccountSettings.WPAPIPushNotificationsListener
     */

    @Override
    public void onSetPushNotificationsStatusResultReturned(WPAPIAccountSettings.WPSetPushNotificationsStatusResult wpSetPushNotificationsStatusResult) {
        Log.d(ReactConstants.TAG, "MyChartLogin#onSetPushNotificationsStatusResultReturned: " + wpSetPushNotificationsStatusResult.name());
    }

    @Override
    public void onPushNotificationsStatusReturned(WPAPIAccountSettings.WPPushNotificationsStatus pushNotificationsStatus) {
        // if enabled, disable it
        Log.d(ReactConstants.TAG, "MyChartLogin#onPushNotificationsStatusReturned: " + pushNotificationsStatus.name());
        if (pushNotificationsStatus == WPAPIAccountSettings.WPPushNotificationsStatus.ON) {
            WPAPIAccountSettings.setPushNotificationsStatus(this.getContext(), this, false);
        }
    }
}
