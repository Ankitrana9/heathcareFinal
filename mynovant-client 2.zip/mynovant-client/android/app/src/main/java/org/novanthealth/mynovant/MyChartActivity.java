package org.novanthealth.mynovant;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.facebook.react.common.ReactConstants;

import epic.mychart.android.library.api.appointments.WPAPIAppointments;
import epic.mychart.android.library.api.billing.WPAPIBilling;
import epic.mychart.android.library.api.general.WPAccessResult;
import epic.mychart.android.library.api.healthsummary.WPAPIHealthSummary;
import epic.mychart.android.library.api.infectioncontrol.WPAPIInfectionControl;
import epic.mychart.android.library.api.medications.WPAPIMedications;
import epic.mychart.android.library.api.messages.WPAPIMessages;
import epic.mychart.android.library.api.shared.IWPPerson;
import epic.mychart.android.library.api.shared.WPAPIActivity;
import epic.mychart.android.library.api.shared.WPAPIPersonManager;
import epic.mychart.android.library.api.springboard.WPAPIHomepage;
import epic.mychart.android.library.api.testresults.WPAPITestResults;
import epic.mychart.android.library.api.todo.WPAPIToDo;

public class MyChartActivity {

    private Context applicationContext;
    private String csn;

    public MyChartActivity() {}

    public MyChartActivity(Context context) {

        this.applicationContext = context;
    }

    public MyChartActivity(Context context,String csn) {

        this.applicationContext = context;
        this.csn = csn;
    }

    public void launch(MyChartActivities activity) {
        switch (activity) {
            case MESSAGES: launchMyChartMessages(); break;
            case HEALTH_SUMMARY: launchMyChartHealthSummary(); break;
            case TEST_RESULTS: launchMyChartTestResults(); break;
            case MEDICATIONS: launchMyChartMedications(); break;
            case TODO: launchMyChartToDo(); break;
            case BILLING: launchMyChartBilling(); break;
            case APPOINTMENT_DETAILS: launchMyChartAppointmentDetails(this.csn); break;
            case APPOINTMENT_SCHEDULING: launchMyChartAppointmentScheduling(); break;
            case CARE_TEAM: launchMyChartActivity(WPAPIActivity.CareTeam); break;
            case TRACK_MY_HEALTH: launchTrackMyHealth(); break;
            case COVID_ACTIVITY: launchCovidActivity(); break;
        }
    }

    private void startActivity(Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        MyChartModule.startMyChartTimer();
        applicationContext.startActivity(intent);
        MainActivity.setMyChartOpen(true);
    }

    private void launchMyChartMessages() {
        WPAccessResult result = WPAPIMessages.accessResultForMessageList();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIMessages.makeMessageListIntent(applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch messages: " + result.name());
        }
    }

    private void launchMyChartHealthSummary() {
        WPAccessResult result = WPAPIHealthSummary.accessResultForHealthSummary();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIHealthSummary.makeHealthSummaryIntent(applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch health summary: " + result.name());
        }
    }

    private void launchMyChartTestResults() {
        WPAccessResult result = WPAPITestResults.accessResultForTestResultsList();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPITestResults.makeTestResultsListIntent(applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch test results: " + result.name());
        }
    }

    private void launchMyChartMedications() {
        WPAccessResult result = WPAPIMedications.accessResultForMedications();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIMedications.makeMedicationsIntent(applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch medications: " + result.name());
        }
    }

    private void launchMyChartToDo() {
        WPAccessResult result = WPAPIToDo.accessResultForToDo();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIToDo.makeToDoIntent(applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch To-do: " + result.name());
        }
    }

    private void launchMyChartBilling() {
        WPAccessResult result = WPAPIBilling.accessResultForBillingAccountList();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIBilling.makeBillingAccountListIntent(applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch billing: " + result.name());
        }
    }

    private void launchCovidActivity() {
        WPAccessResult result = WPAPIInfectionControl.accessResultForCovidStatus();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIInfectionControl.makeCovidStatusIntent(applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch covidActivity: " + result.name());
        }
    }

    private void launchTrackMyHealth() {
        Log.d(ReactConstants.TAG, "MyChartActivity#launchTrackMyHealth");
        String activity = WPAPIActivity.TrackMyHealth;

        IWPPerson currentPerson = WPAPIPersonManager.getCurrentPerson();

        WPAccessResult result =
                WPAPIHomepage.accessResultForActivity(activity, currentPerson);

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            MyChartModule.emitEventMyChartEventResponse("onActivitySucceeded");
            Intent intent = WPAPIHomepage
                    .makeIntentForActivity(activity, currentPerson, applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "MyChartActivity#launchTrackMyHealth name:    " + result.name());
            Log.d(ReactConstants.TAG, "MyChartActivity#launchTrackMyHealth ordinal: " + result.ordinal());
            MyChartModule.emitEventMyChartEventResponse("onActivityFails");
        }
    }

    private void launchMyChartAppointmentDetails(String csn) {
        WPAccessResult result = WPAPIAppointments.accessResultForFutureAppointment();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIAppointments.makeFutureAppointmentDetailIntent(applicationContext, csn);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch Appointment Details: " + result.name());
        }
    }

    private void launchMyChartAppointmentScheduling() {
        WPAccessResult result = WPAPIAppointments.accessResultForScheduling();

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIAppointments.makeSchedulingIntent(applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch Appointment Scheduling: " + result.name());
        }
    }

    private void launchMyChartActivity(String activity) {
        IWPPerson currentPerson = WPAPIPersonManager.getCurrentPerson();

        WPAccessResult result =
                WPAPIHomepage.accessResultForActivity(activity, currentPerson);

        if (result == WPAccessResult.ACCESS_ALLOWED) {
            Intent intent = WPAPIHomepage
                    .makeIntentForActivity(activity, currentPerson, applicationContext);
            startActivity(intent);
        } else {
            Log.d(ReactConstants.TAG, "==> Could not launch " + activity + ": " + result.name());
        }
    }

}
