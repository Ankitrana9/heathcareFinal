//
//  AppDelegate.swift
//  MyNovant
//
//  Created by Lugo, Mark C on 4/29/20.
//  Copyright © 2020 Facebook. All rights reserved.
//

import UIKit
import Foundation
import Firebase

class AppDelegate: UIResponder, UIApplicationDelegate, RCTBridgeDelegate {

  var window: UIWindow?

  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions:[UIApplication.LaunchOptionsKey: Any]?) -> Bool {

    FirebaseApp.configure()

    WPAPIAppDelegate.application(application, didFinishLaunchingWithOptions: launchOptions)

    let jsCodeLocation: URL = RCTBundleURLProvider.sharedSettings().jsBundleURL(forBundleRoot: "index", fallbackResource:nil)

    let rootView = RCTRootView(bundleURL: jsCodeLocation, moduleName: "MyNovant", initialProperties: nil, launchOptions: launchOptions)

    rootView.backgroundColor = UIColor.init(red: 1.0, green: 1.0, blue: 1.0, alpha: 1)

    self.window = UIWindow.init(frame: UIScreen.main.bounds)

    let rootViewController = UIViewController()
    rootViewController.view = rootView

    let nav = MyNovantNavigationController()
    nav.pushViewController(rootViewController, animated: true)

    self.window?.rootViewController = nav
    self.window?.makeKeyAndVisible()

    return true
  }

  func sourceURL(for bridge: RCTBridge!) -> URL! {
    #if DEBUG
    return RCTBundleURLProvider.sharedSettings().jsBundleURL(forBundleRoot: "index", fallbackResource: nil)
    #else
      return Bundle.main.url(forResource: "main", withExtension: "jsbundle")
    #endif
  }

}
