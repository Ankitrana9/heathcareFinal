//
//  SwiftApplication.swift
//  MyNovant
//
//  Created by Lugo, Mark C on 4/29/20.
//  Copyright © 2020 Facebook. All rights reserved.
//

import Foundation

struct Global {

  static var isTimerStarted: Bool = false
  static var timer = Timer()

  static func startTimer() {
    if (isTimerStarted == false) {
      Global.isTimerStarted = true
    }
    Global.timer.invalidate()
    Global.timer = Timer.scheduledTimer(withTimeInterval: (3 * 60), repeats: false, block: {_ in
        Global.timer.invalidate()
        Global.isTimerStarted = false
        WPAPIAuthentication.logout();
        LogoutEmitter.shared?.logout()
      })
  }
}

class SwiftApplication : UIApplication {

  override func sendEvent(_ event: UIEvent) {
    super.sendEvent(event)

    if (Global.isTimerStarted) {
      if let touches = event.allTouches {
        for touch in touches {
          if touch.phase == UITouch.Phase.began {
            Global.startTimer()
          }
        }
      }
    }

  }
}
