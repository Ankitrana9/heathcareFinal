module.exports = {
  preset: 'react-native',
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node', 'map'],
  transformIgnorePatterns: ['node_modules/(?!(react-native|react-native-button|native-base-.*|react-native-.*))'],
  moduleNameMapper: {
    "\\.svg": "<rootDir>/svgMock.js"
  },
  transformIgnorePatterns: ['<rootDir>/node_modules/react-native-community/blur']
};
