package org.novanthealth.mynovant;

import android.content.Intent;
import android.util.Log;
import android.view.MotionEvent;

import com.facebook.react.ReactActivity;

public class MainActivity extends ReactActivity {

  public static boolean isMyChartOpen = false;

  /**
   * Returns the name of the main component registered from JavaScript. This is used to schedule
   * rendering of the component.
   */
  @Override
  protected String getMainComponentName() { return "MyNovant"; }

  public static void setMyChartOpen(Boolean isOpen) {
    isMyChartOpen = isOpen;
  }

  @Override
  protected void onResume() {
    super.onResume();
    Log.d("ReactNative", "MainActivity#onResume");

    Log.d("ReactNative", "MainActivity# isMyChartOpen -> " + isMyChartOpen);

    if (isMyChartOpen) {
      Log.d("ReactNative", "MainActivity# MyChart was open!");
      MyChartModule.emitUpdateAppointmentsEvent();
      isMyChartOpen = false;
    }

  }
}
