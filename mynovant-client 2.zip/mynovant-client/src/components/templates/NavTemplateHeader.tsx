import React, {ReactElement} from 'react';
import {Body, Button, Header, Icon, Left, Right, Text, View} from "native-base";
import globalStyles, {palette} from "../../Style";
import MyNovantLogo from "../../../assets/mynovant_logo_rgb.svg";
import {Platform} from "react-native";
import Modal from "react-native-modal";
import {PatientProps} from "../../contexts/PatientContext";
import withPatientInfo from "../../contexts/withPatientInfo";
import {environments, MyNovant} from "../../system/MyNovant";

type Props = {
    title: string,
    right?: ReactElement,
    menuContents: ReactElement,
    onMenuHide?: () => void
}

type State = {
    startsOpen: boolean,
    animSpeed: number
}

class NavTemplateHeader extends React.Component<Props & PatientProps, State> {

    state = {
        startsOpen: false,
        animSpeed: 1
    }

    componentDidMount() {
        if (this.props.isMenuOpen) {
            this.setState({startsOpen: true})
        } else {
            this.setState({animSpeed: 400})
        }
    }

    componentDidUpdate(prevProps: Readonly<Props & PatientProps>, prevState: Readonly<State>, snapshot?: any) {
        if (this.state.startsOpen) {
            this.setState({startsOpen: false, animSpeed: 400})
        }
    }

    setMenuOpen(isOpen: boolean) {
        this.props.setMenuOpen(isOpen)
    }

    showEasterEgg = async() => {
        if (MyNovant.getEnvironment() !== environments.prod) {
            this.props.showEasterEgg(!this.props.showingEasterEgg)
            this.setMenuOpen(true)
        }
    }

    render() {

        const { animSpeed } = this.state

        return (
            <View testID='header'>
                <Header style={{
                        backgroundColor: 'white',
                        padding: 16,
                        paddingTop: 24,
                    }}
                    androidStatusBarColor='white'
                    iosBarStyle="dark-content"
                >
                    <Left style={{ flex: 1 }}>
                        <Button transparent testID='menuButton' onPress={() => this.setMenuOpen(true)}>
                            <Icon name='menu' style={{ marginLeft: 10, color: palette.aubergine }} />
                        </Button>
                    </Left>
                    <Body>

                        { MyNovant.getEnvironment() !== environments.prod ?
                            <Button transparent onPress={() => this.showEasterEgg()}>
                                <MyNovantLogo style={{ alignSelf: 'center' }} width={120} height={120} fill={palette.aubergine} testID='logo' />
                            </Button>
                            :
                            <MyNovantLogo style={{ alignSelf: 'center' }} width={120} height={120} fill={palette.aubergine} testID='logo' />
                        }

                    </Body>
                    <Right testID='right' style={{ flex: 1 }}>
                        { this.props.right }
                    </Right>
                </Header>
                <View testID='secondaryHeader'
                      style={{
                          borderBottomWidth: Platform.select({android: 1.2, ios: 0.6}),
                          borderBottomColor: palette.alto,
                          height: 45,
                          backgroundColor: 'white',
                          display: 'flex',
                          flexDirection: 'row',
                          justifyContent: 'center',
                          marginTop: -2,
                      }}>
                    <Text maxFontSizeMultiplier={2} testID='pageTitle' style={{
                        ...globalStyles.bodyText,
                        display: 'flex',
                        alignSelf: 'center',
                        fontSize: 18,
                        fontFamily: 'Whitney-Medium',
                        color: palette.aubergine,
                    }}>
                        { this.props.title }
                    </Text>
                </View>

                <Modal isVisible={this.props.isMenuOpen}
                       testID='menuModal'
                       swipeDirection='left'
                       onModalHide={this.props.onMenuHide}
                       onSwipeComplete={() => this.setMenuOpen(false)}
                       onBackdropPress={() => this.setMenuOpen(false)}
                       animationIn='slideInLeft'
                       animationOut='slideOutLeft'
                       animationInTiming={animSpeed}>
                    { this.props.menuContents }
                </Modal>

            </View>
        )
    }
}

export default withPatientInfo(NavTemplateHeader)
