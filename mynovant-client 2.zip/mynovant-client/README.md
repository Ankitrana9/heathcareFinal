# :space_invader: React Native Template TypeScript

<p>
  <a href="https://travis-ci.org/react-native-community/react-native-template-typescript">
    <img alt="Build Status" src="https://img.shields.io/travis/react-native-community/react-native-template-typescript.svg" target="_blank" />
  </a>
  <a href="https://github.com/react-native-community/react-native-template-typescript#readme">
    <img alt="Documentation" src="https://img.shields.io/badge/documentation-yes-brightgreen.svg" target="_blank" />
  </a>
  <a href="https://github.com/react-native-community/react-native-template-typescript/graphs/commit-activity">
    <img alt="Maintenance" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg" target="_blank" />
  </a>
  <a href="https://github.com/react-native-community/react-native-template-typescript/blob/master/LICENSE">
    <img alt="License: MIT" src="https://img.shields.io/badge/License-MIT-yellow.svg" target="_blank" />
  </a>
</p>

> Clean and minimalist React Native template for a quick start with TypeScript.


The gradle wrapper at the root of this project is solely designed to run DependencyCheck, a Static Code Analyzer for
dependencies.

To use this feature, run the following:

npm install --package.lock

Then, run:

./gradlew dependencyCheckAnalyze

sudo xcode-select -s /Applications/Xcode.app/

Specify the version to point to (example : ./Xcode_12.4.app)


## Setup

* Install Android Studio


* modify your .bash_profile. Open with:

`$ vi ~/.bash_profile`

and ensure that you have the following:
```
export PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"

export JAVA_HOME=/Library/Java/JavaVirtualMachines/openjdk-13.0.1.jdk/Contents/Home/
export ANDROID_HOME=/Users/[your user folder]/Library/Android/sdk/
export PATH="${ANDROID_HOME}emulator:$PATH"
```

When you are done, write your changes and refresh your terminal with:

`source ~/.bash_profile`

## :bookmark: License

This project is [MIT](LICENSE) licensed.
