//
//  main.swift
//  MyNovant
//
//  Created by Lugo, Mark C on 4/29/20.
//  Copyright © 2020 Facebook. All rights reserved.
//

import Foundation
import UIKit

UIApplicationMain(
  CommandLine.argc,
  CommandLine.unsafeArgv,
  NSStringFromClass(SwiftApplication.self),
  NSStringFromClass(AppDelegate.self)
)
