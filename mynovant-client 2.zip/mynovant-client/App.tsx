import React, { Component } from 'react';
import { createSwitchNavigator, NavigationActions } from "react-navigation";
import { createAppContainer } from "react-navigation";
import HomePage from './src/components/pages/HomePage';
import LoginPage from './src/components/pages/LoginPage';
import MyAppointmentsPage from './src/components/pages/MyAppointmentsPage';
import MyMessagesPage from './src/components/pages/MyMessagesPage';
import PatientProvider from "./src/contexts/PatientProvider";
import { Container } from "native-base";
import SplashScreenPage from "./src/components/pages/SplashScreenPage";
import createAnimatedSwitchNavigator from 'react-navigation-animated-switch';
import { Transition } from 'react-native-reanimated'
import SignOutPage from "./src/components/pages/SignOutPage";
import PreLoginHomePage from "./src/components/pages/PreLoginHomePage";
import { WelcomePage } from "./src/components/pages/WelcomePage";
import { PreLoginAppointmentsPage } from "./src/components/pages/PreLoginAppointmentsPage";
import { PreLoginMessagesPage } from "./src/components/pages/PreLoginMessagesPage";
import { PreLoginPhysicianFinderPage } from "./src/components/pages/PreLoginPhysicianFinderPage";
import { PhysicianFinderPage } from "./src/components/pages/PhysicianFinderPage";
import { ContactCenterPage } from "./src/components/pages/ContactCenterPage";
import { PreLoginContactCenterPage } from "./src/components/pages/PreLoginContactCenterPage";
import { MyNovant } from "./src/system/MyNovant";
import PreLoginSettingsPage from "./src/components/pages/PreLoginSettingsPage";
import SettingsPage from './src/components/pages/SettingsPage';
import { AccountCreationScreen2 } from "./src/components/pages/AccountCreationScreen2";
import BillingOptionsPage from "./src/components/pages/BillingOptionsPage";
import NovantHealthBillingPage from "./src/components/pages/NovantHealthBillingPage";
import LegalInformationPage from "./src/components/pages/LegalInformationPage";
import PasswordUpdatePage from "./src/components/pages/PasswordUpdatePage";
import LoginAndPasswordPage from "./src/components/pages/LoginAndPasswordPage";
import LegalOptionsPage from "./src/components/pages/LegalOptionsPage";
import NovantChatScreen from "./src/components/Chatbot/NovantChatScreen";
import { Webframe } from './src/components/templates/Webframe';


const splashScreen = {
    SplashScreen: { screen: SplashScreenPage },
    FirstTimeWelcome: { screen: WelcomePage },
    PreLoginWelcome: { screen: PreLoginHomePage },
}

const Splash = createAnimatedSwitchNavigator(
    splashScreen,
    {
        transition: (
            <Transition.Together>
                <Transition.Out
                    type="fade"
                    durationMs={700}
                    interpolation="linear"
                />
            </Transition.Together>
        ),
    }
);

const LoginRoutes = {
    Login: { screen: LoginPage },
    Welcome: { screen: HomePage },

    //new account creation screens
    AccountCreationScreenPage1: { screen: AccountCreationScreen2 },
}

const Login = createAnimatedSwitchNavigator(
    LoginRoutes,
    {
        transition: (
            <Transition.Together>
                {MyNovant.getPlatform() === 'ios' &&
                    <Transition.In
                        type="fade"
                        durationMs={700}
                    // interpolation="linear"
                    />
                }

                {MyNovant.getPlatform() === 'android' &&
                    <Transition.Out
                        type="fade"
                        durationMs={700}
                        interpolation="linear"
                    />
                }
            </Transition.Together>
        ),
    }
);


const AppNavigation = createSwitchNavigator(
    {
        Splash: { screen: Splash },
        PreLoginWelcome: { screen: PreLoginHomePage },
        Login: { screen: Login },
        Welcome: { screen: HomePage },
        AppointmentsPage: { screen: MyAppointmentsPage },
        MessagesPage: { screen: MyMessagesPage },
        PhysicianFinder: { screen: PhysicianFinderPage },
        ContactCenter: { screen: ContactCenterPage },
        Settings: { screen: SettingsPage },
        NovantBilling: { screen: NovantHealthBillingPage },
        PasswordUpdatePage: { screen: PasswordUpdatePage },
        LoginAndPasswordPage: { screen: LoginAndPasswordPage },
        LoginPage: { screen: LoginPage },
        //new sign out page
        SignOut: { screen: SignOutPage },

        // pre login navigation
        PreLoginAppointments: { screen: PreLoginAppointmentsPage },
        PreLoginMessages: { screen: PreLoginMessagesPage },
        PreLoginPhysicianFinder: { screen: PreLoginPhysicianFinderPage },
        PreLoginContactCenter: { screen: PreLoginContactCenterPage },
        PreLoginSettings: { screen: PreLoginSettingsPage },

        // chatboot Pages
        NovantChat: { screen: NovantChatScreen },

        // option Pages
        BillingOptions: { screen: BillingOptionsPage },
        LegalInformation: { screen: LegalInformationPage },
        LegalOptions: { screen: LegalOptionsPage },
        Webframe: { screen: Webframe }
    }
);

const AppContainer = createAppContainer(AppNavigation);

class App extends Component<{}, { isReady: boolean }> {
    state = { isReady: false };

    appContainerRef

    async componentDidMount() {
        this.setState({ isReady: true });
    }

    navigate = (route: string) => {
        this.appContainerRef.dispatch(NavigationActions.navigate(
            { routeName: route }
        ))
    }

    render() {
        if (!this.state.isReady) {
            return <Container />;
        }

        return (
            <PatientProvider navigate={this.navigate}>
                <AppContainer ref={(ref) => this.appContainerRef = ref} />
            </PatientProvider>
        );
    }

}

export default App;
