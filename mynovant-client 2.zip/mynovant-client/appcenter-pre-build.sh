#!/usr/bin/env bash

cd $APPCENTER_SOURCE_DIRECTORY/

yarn pre-build-link
