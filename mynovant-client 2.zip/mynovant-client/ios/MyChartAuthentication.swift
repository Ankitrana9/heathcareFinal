//
//  MyChartAuthentication.swift
//  MyNovant
//
//  Created by Ishimwe, Patrick on 3/19/20.
//  Copyright © 2020 Facebook. All rights reserved.
//

import UIKit
import LocalAuthentication
import FirebaseAnalytics

class MyChartAuthentication: UIViewController, WPAPIAuthenticationDelegate {

  var username: String
  var password: String
  var isProd: Bool

  init(username: String, password: String, isProd: Bool) {
    self.username = username
    self.password = password
    self.isProd = isProd

    super.init(nibName: nil, bundle: nil)
  }

  required init?(coder: NSCoder) {
    fatalError("Will never use this. Not using Storyboards!")
  }

  override func viewDidAppear(_ animated: Bool) {
    NSLog("MyChartAuthentication#login auth status -> \(WPAPIUserManager.getAuthenticationStatus().rawValue)");
//    kWPNotAuthenticated = 0,
//    kWPLimitedAuthentication = 1,
//    kWPFullyAuthenticated = 2,
  }

  override func viewDidLoad() {
    if (WPAPIUserManager.isLoggedIn() == false) {
      self.login(username: self.username, password: self.password)
    }
  }


  func login(username: String, password: String) {
    NSLog("MyChartAuthentication#login");
    
    WPAPIAuthentication.login(withUsername: username,
                              password: password,
                              delegate: self);

//    kWPNotAuthenticated = 0,
//    kWPLimitedAuthentication = 1,
//    kWPFullyAuthenticated = 2,

    NSLog("MyChartAuthentication#login -> done!");
  }

  func logout() {
    NSLog("MyChartAuthentication#logout");
    Global.timer.invalidate()
    Global.isTimerStarted = false

    WPAPIAuthentication.logout();

    NSLog("MyChartAuthentication#logout -> done!");
  }

  //MARK: WPAPIAuthenticationDelegate
  // add override

  func loginSucceeded() {
    NSLog("MyChartAuthentication#loginSucceeded");

    DispatchQueue.main.async {
      if (self.isProd) {
        NSLog("MyChartAuthentication#loginSucceeded - logging to GA");
        Analytics.logEvent(AnalyticsEventLogin, parameters: [
          "app": "MyNovant",
        ])
      }
      
      self.dismiss(animated: false, completion: nil)
      MyChartAuthResponseEmitter.shared?.sendWithResponse(isSuccessful: true)
    }
  }

  func loginFailedWithError(_ error: Error) {
    NSLog("MyChartAuthentication#loginFailedWithError");
    NSLog("MyChartAuthentication#loginFailedWithError self -> \(error)");
    NSLog("MyChartAuthentication#loginFailedWithError auth status -> \(WPAPIUserManager.getAuthenticationStatus().rawValue)");

    DispatchQueue.main.async {
      self.dismiss(animated: false, completion: nil)
      MyChartAuthResponseEmitter.shared?.sendWithResponse(isSuccessful: false)
    }
  }

  func getPresentationViewController() -> UIViewController {
    NSLog("MyChartAuthentication#getPresentationViewController");
    // required to present Terms & Conditions, 2 factor auth, and possibly password resets
    return self
  }

}
