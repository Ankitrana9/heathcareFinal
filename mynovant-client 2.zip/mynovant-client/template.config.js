module.exports = {
  placeholderName: 'mynovant-client',
  templateDir: './template',
}
