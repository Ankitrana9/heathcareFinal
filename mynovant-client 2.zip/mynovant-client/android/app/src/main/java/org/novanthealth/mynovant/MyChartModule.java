package org.novanthealth.mynovant;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;

import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.HashMap;
import java.util.Map;

import epic.mychart.android.library.api.general.WPAPIMyChartLibrary;
import epic.mychart.android.library.api.prelogin.WPAPIServer;
import epic.mychart.android.library.api.timer.WPAPIIdleTimer;


public class MyChartModule extends ReactContextBaseJavaModule
        implements WPAPIIdleTimer.IWPOnIdleTimeoutListener {

    private static ReactApplicationContext reactContext;

    public MyChartModule(ReactApplicationContext context) {
        super(context);

        reactContext = context;
    }

    @Override
    public String getName() {
        return "MyChartModule";
    }

    @Override
    public Map<String, Object> getConstants() {
        final Map<String, Object> constants = new HashMap<>();
        constants.put("shootin", "crap");

        Log.d("ReactNative", "==========================> getting those constants! ");

        return constants;
    }

    @ReactMethod
    public void authenticateWithMyChart(String username, String password, boolean isProd) {
        Log.d("ReactNative", "MyChartModule#login");

        String url;

        if (isProd) {
            url = "https://www.novantmychart.org/interconnect-MCM_PRD/Wcf/Epic.MyChartMobile/MyChartMobile.svc/rest";
        } else {
            url = "https://mycharttest.novanthealth.org/Interconnect-MCM_TST/Wcf/Epic.MyChartMobile/MyChartMobile.svc/rest";
        }

        try {
            WPAPIServer.setInterconnectTestingUrl(url);

            WPAPIIdleTimer.removeTimeoutListener(this);
            WPAPIIdleTimer.addTimeoutListener(this);

            Activity activity = this.getCurrentActivity();
            Intent intent = new Intent(activity, MyChartLogin.class);
            intent.putExtra("username", username);
            intent.putExtra("password", password);
            intent.putExtra("isProd", isProd);

            activity.startActivity(intent);
        } catch (Exception e) {
            Log.d("ReactNative", "MyChartModule#login Error -> " + e.getMessage());
            MyChartModule.emitEventMyChartAuthResponse(false);
        }
    }

    @ReactMethod
    public void logout() {
        Log.d("ReactNative", "MyChartModule#logout");
        WPAPIIdleTimer.removeTimeoutListener(this);
        MyChartModule.stopTimerAndLogOutOfMyChart();
    }

    @ReactMethod
    public void launchMyChart() {
        Log.d("ReactNative", "MyChartModule#showECheckin");

        new MyChartSpringBoard(reactContext.getApplicationContext()).launchMyChart();
    }

    @ReactMethod
    public void launchMyChartMessages() {
        Log.d("ReactNative", "MyChartModule#launchMyChartMessages");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.MESSAGES);
    }

    @ReactMethod
    public void launchMyChartHealthSummary() {
        Log.d("ReactNative", "MyChartModule#launchMyChartHealthSummary");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.HEALTH_SUMMARY);
    }

    @ReactMethod
    public void launchMyChartTestResults() {
        Log.d("ReactNative", "MyChartModule#launchMyChartTestResults");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.TEST_RESULTS);
    }

    @ReactMethod
    public void launchMyChartMedications() {
        Log.d("ReactNative", "MyChartModule#launchMyChartMedications");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.MEDICATIONS);
    }

    @ReactMethod
    public void launchMyChartToDo() {
        Log.d("ReactNative", "MyChartModule#launchMyChartToDo");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.TODO);
    }

    @ReactMethod
    public void launchMyChartBilling() {
        Log.d("ReactNative", "MyChartModule#launchMyChartBilling");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.BILLING);
    }

    @ReactMethod
    public void launchMyChartAppointmentDetails(String csn) {
        Log.d("ReactNative", "MyChartModule#launchMyChartAppointmentDetails");
        new MyChartActivity(reactContext.getApplicationContext(), csn)
                .launch(MyChartActivities.APPOINTMENT_DETAILS);
    }

    @ReactMethod
    public void launchMyChartAppointmentScheduling() {
        Log.d("ReactNative", "MyChartModule#launchMyChartAppointmentScheduling");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.APPOINTMENT_SCHEDULING);
    }

    @ReactMethod
    public void launchCareTeam() {
        Log.d("ReactNative", "MyChartModule#launchCareTeam");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.CARE_TEAM);
    }

    @ReactMethod
    public void launchTrackMyHealth() {
        Log.d("ReactNative", "MyChartModule#launchTrackMyHealth");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.TRACK_MY_HEALTH);
    }
    @ReactMethod
    public void launchCovidActivity() {
        Log.d("ReactNative", "MyChartModule#launchCovidActivity");
        new MyChartActivity(reactContext.getApplicationContext())
                .launch(MyChartActivities.COVID_ACTIVITY);
    }

    @ReactMethod
    public void setScreenshotsEnabled(boolean isEnabled) {
        Log.d("ReactNative", "MyChartModule#setScreenshotsEnabled");
        Activity activity = reactContext.getCurrentActivity();

        try {
            WPAPIMyChartLibrary.setScreenshotEnabled(activity, isEnabled);
        } catch (Exception e) {
            Log.d("ReactNative", "MyChartModule#setScreenshotsEnabled Error -> " + e);
        }
    }

    @ReactMethod
    public void stopTimer() {
        Log.d("ReactNative", "MyChartModule#stopTimer");
        WPAPIIdleTimer.stopTimer();
    }

    @ReactMethod
    public void sendEventToGA(String eventName) {
        Log.d("ReactNative", "MyChartModule#sendEventToGA");

        FirebaseAnalytics.getInstance(reactContext.getApplicationContext())
                        .logEvent(eventName, new Bundle());
    }

    @ReactMethod
    public void getCedarUrl(Callback callback) {
        Log.d("ReactNative", "MyChartModule#getCedarUrl");
        new Cedar(callback);
    }

    /**
     * Helper Methods
     */

    static void startMyChartTimer() {
        WPAPIIdleTimer.startTimer();
    }

    static void stopMyChartTimer() {
        WPAPIIdleTimer.stopTimer();
    }

    static void stopTimerAndLogOutOfMyChart() {
        MyChartModule.stopMyChartTimer();

        Activity activity = reactContext.getCurrentActivity();
        Intent intent = new Intent(activity, MyChartLogout.class);

        activity.startActivity(intent);
    }

    static void emitEventLogout() {
        MyChartModule.emitEvent("onLogout", null);
    }

    static void emitUpdateAppointmentsEvent() {
        MyChartModule.emitEvent("onCloseMyChartActivity", null);
    }

    static void emitEventMyChartAuthResponse(boolean isSuccessful) {
        Log.d("ReactNative", "MyChartModule#emitEventMyChartAuthResponse");

        WritableMap params = Arguments.createMap();
        params.putBoolean("authResponse", isSuccessful);

        MyChartModule.emitEvent("onMyChartAuthResponse", params);
    }

    static void emitEventMyChartEventResponse(String activityEvent) {
        Log.d("ReactNative", "emitEventMyChartEventResponse");

        MyChartModule.emitEvent(activityEvent, null);
    }

    static void emitEvent(String eventName, @Nullable WritableMap params) {
        MyChartModule.getReactContext()
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit(eventName, params);
    }

    public static ReactApplicationContext getReactContext() {
        return reactContext;
    }


    /**
     * Methods for WPAPIIdleTimer.IWPOnIdleTimeoutListener
     */

    @Override
    public void onIdleTimeout() {
        /* Do additionally logic here.  This may be closing a video chat or other
         * tasks.  Note: the idle timeout will kick the user out of the current activity
         * and return it to the activity defined in WPApplication.getIdleTimeoutActivityClass.
         * This also is called before the logout call is called.
         */
        WPAPIIdleTimer.removeTimeoutListener(this);
    }

    @Override
    public void onIdleTimeoutComplete() {
    }

}
