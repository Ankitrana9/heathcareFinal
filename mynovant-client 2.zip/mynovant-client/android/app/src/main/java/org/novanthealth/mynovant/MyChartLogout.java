package org.novanthealth.mynovant;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

import com.facebook.react.common.ReactConstants;

import epic.mychart.android.library.api.authentication.WPAPIAuthentication;

public class MyChartLogout extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(ReactConstants.TAG, "MyChartLogout#onCreate");

        WPAPIAuthentication.logout(this);
    }
}
