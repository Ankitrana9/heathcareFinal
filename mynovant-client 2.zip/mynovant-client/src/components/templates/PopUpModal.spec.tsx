import React from 'react'

import {render} from "react-native-testing-library";
import {ModalPopupOption, PopUpModal} from "./PopUpModal";
import {advance, fireEventPress} from "../../support/specHelper";

describe('PopUp Modal', () => {

    let container

    const defaultOptions = [{text: '', onPress: jest.fn(), color: 'black'} as ModalPopupOption]

    const renderComponent = (title: string = '',
                             options: ModalPopupOption[] = defaultOptions,
                             testID: string = 'theModal') => {
        return render(
            <PopUpModal title={title}
                        options={options}
                        testID={testID}
            />)
    }

    let options

    beforeEach(() => {
        options = [
            {text: 'WHAT IS GOING ON?', onPress: jest.fn(), color: 'red'},
            {text: 'WHERE CAN WE FISH?', onPress: jest.fn(), color: 'green'}
        ]

        container =  renderComponent('', options)
    })

    it('should have a TestID', () => {
        expect(container.queryAllByTestId('theModal')[0]).toBeTruthy()
    })

    describe('title', () => {

        it('should have a title', () => {
            container =  renderComponent('a title!')
            expect(container.queryByText('a title!')).toBeTruthy()

            container =  renderComponent('another title!')
            expect(container.queryByText('another title!')).toBeTruthy()
        })

    });

    describe('options', () => {

        it('should have one or more', () => {
            expect(container.queryByText('WHAT IS GOING ON?')).toBeTruthy()
            expect(container.queryByText('WHERE CAN WE FISH?')).toBeTruthy()
        })

        it('should call associated callback method when pressed', async () => {
            await fireEventPress(container.queryByText('WHAT IS GOING ON?'))

            await advance()
                expect(options[0].onPress).toHaveBeenCalled()

            await fireEventPress(container.queryByText('WHERE CAN WE FISH?'))

            await advance()
                expect(options[1].onPress).toHaveBeenCalled()
        });
    });

})
