//
//  MyNovantNavigationController.swift
//  MyNovant
//
//  Created by Lugo, Mark C on 10/15/20.
//  Copyright © 2020 Facebook. All rights reserved.
//

import Foundation

class MyNovantNavigationController: UINavigationController {
  
  var isMyChartVisible: Bool
  
  init() {
    self.isMyChartVisible = false
    
    super.init(nibName: nil, bundle: nil)
       
    self.navigationBar.barTintColor = UIColor(red: 0.32, green: 0.18, blue: 0.43, alpha: 1.00)
    self.navigationBar.tintColor = UIColor.white
    self.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
    
    self.navigationBar.topItem?.title = ""
    
    self.hidesBarsOnTap = false
    self.navigationBar.isHidden = true
    self.hidesBottomBarWhenPushed = true
  }
  
  required init?(coder: NSCoder) {
    fatalError("Will never use this. Not using Storyboards!")
  }
  
  @objc(setMyChartVisible:)
  func setMyChartVisible(isVisible: Bool) {
    self.isMyChartVisible = isVisible
  }
  
  override func popViewController(animated: Bool) -> UIViewController? {
    let viewController = self.topViewController

    super.popViewController(animated: animated)

    if (self.viewControllers.count == 1 && self.isMyChartVisible) {
      self.navigationBar.isHidden = true
      self.hidesBottomBarWhenPushed = true

      AppointmentEmitter.shared?.updateAppointment()
      self.setMyChartVisible(isVisible: false)
    }

    return viewController
  }


  override func dismiss(animated flag: Bool, completion: (() -> Void)? = nil) {

    super.dismiss(animated: flag, completion: completion)

    if (self.viewControllers.count == 1 && self.isMyChartVisible) {
      self.navigationBar.isHidden = true
      self.hidesBottomBarWhenPushed = true

      AppointmentEmitter.shared?.updateAppointment()
      self.setMyChartVisible(isVisible: false)
    }
  }
  
}
