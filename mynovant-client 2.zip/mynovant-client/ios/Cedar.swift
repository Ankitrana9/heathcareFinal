//
//  Ceder.swift
//  MyNovant
//
//  Created by Lugo, Mark C on 11/25/20.
//  Copyright © 2020 Facebook. All rights reserved.
//

import Foundation

class Cedar: NSObject, WPAPIFDIDelegate {
  
  var callback: RCTResponseSenderBlock
  
  init(callback: @escaping RCTResponseSenderBlock) {
    NSLog("Cedar#init")
    self.callback = callback
    super.init()
    WPAPIFDILink.getUrlString(withFdiID: "100085", callback: self)
  }
  
  //MARK: Protocols
  
  func didGetUrlString(_ url: String!) {
    NSLog("Cedar#didGetUrlString -> \(String(describing: url))")
    callback([url!])
  }
  
  func didFailToGetUrlWithError(_ error: Error!) {
    NSLog("Cedar#didFailToGetUrlWithError -> \(String(describing: error))")
  }
  
}
