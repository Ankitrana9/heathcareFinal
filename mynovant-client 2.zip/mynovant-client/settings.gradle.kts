rootProject.name = "MyNovant"
