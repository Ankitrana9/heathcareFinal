package org.novanthealth.mynovant;

public enum MyChartActivities {
    MESSAGES,
    HEALTH_SUMMARY,
    TEST_RESULTS,
    MEDICATIONS,
    TODO,
    BILLING,
    APPOINTMENT_DETAILS,
    APPOINTMENT_SCHEDULING,
    CARE_TEAM,
    TRACK_MY_HEALTH,
    COVID_ACTIVITY
}
