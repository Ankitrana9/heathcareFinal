import org.jetbrains.kotlin.gradle.tasks.KotlinCompile


plugins {
	id("org.owasp.dependencycheck") version "5.3.2.1"
	kotlin("jvm") version "1.3.72"
	kotlin("plugin.spring") version "1.3.72"
	kotlin("plugin.jpa") version "1.3.72"
}

group = "org.novanthealth.mynovant"
version = "0.0.1-SNAPSHOT"
java.sourceCompatibility = JavaVersion.VERSION_11

//val developmentOnly by configurations.creating
//configurations {
//	runtimeClasspath {
//		extendsFrom(developmentOnly)
//	}
//}

repositories {
	mavenCentral()
}

dependencies {
}

dependencyCheck {
	this.analyzers.assemblyEnabled = false
	this.analyzers.retirejs.enabled = false
}
